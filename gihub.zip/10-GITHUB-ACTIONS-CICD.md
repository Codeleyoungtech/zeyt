# Zeyt — GitHub Actions CI/CD

**Companion to:** 02-DEVELOPMENT-PLAN.md (Phase 8 — Packaging)
**Last updated:** 2026-06-25

---

## 1. The mental model (read this first)

GitHub Actions does **not** work like WSL or any form of one-OS-emulating-
another. When the workflow below runs, GitHub spins up **three separate,
real virtual machines** — an actual Windows Server VM, an actual macOS
VM, an actual Ubuntu Linux VM — all in parallel, all independent of each
other. Each one checks out your code fresh and compiles it using its own
**native** toolchain (MSVC on Windows, Xcode/clang on macOS, gcc on
Linux). There is no cross-compilation trick happening — Tauri's own docs
are explicit that meaningful cross-compilation isn't possible for it,
which is exactly why this CI approach is the standard, recommended path
rather than a workaround.

So: **one trigger (a push or tag), three independent native build
pipelines running concurrently, each producing a platform-correct
installer.** Real Windows building a real `.msi`, real macOS building a
real `.dmg`, real Linux building a real `.AppImage`/`.deb` — not
translations or emulations of each other.

This is also, practically, the *only* way you get a macOS build of Zeyt
to exist at all, since you don't own a Mac to build one locally.

---

## 2. The workflow file

Save the companion file as `.github/workflows/build.yml` in the Zeyt repo
root (GitHub Actions only recognizes workflow files in that exact path).

It's configured to:
- Run on every push to `main` (a sanity-check build across all 3 OSes —
  catches "works on my machine" bugs immediately, before a release).
- Run on pushing a tag matching `zeyt-v*` (e.g. `zeyt-v0.1.0`) — this is
  what actually produces a real GitHub Release with installers attached.
- Run on pull requests targeting `main` — so you see build status before
  merging anything.

Key details already filled in correctly for Zeyt specifically:
- **pnpm**, not npm/yarn — matches your actual lockfile.
- **Linux build target is `ubuntu-22.04`, not `ubuntu-latest`.** This is
  deliberate: building on the *oldest* supported base maximizes glibc
  compatibility with newer systems (including your own Mint/Ubuntu
  24.04 machine) — building on the newest OS first can produce a binary
  that fails on older systems with an older glibc.
- **`libwebkit2gtk-4.1-dev`**, matching the exact dependency list
  validated on your real laptop during the Phase 0 hardware gate test —
  not the older `4.0` package some outdated tutorials still reference.
- **macOS matrix includes both Apple Silicon and Intel** as separate
  build targets, so M1/M2/M3 Mac users and older Intel Mac users both get
  a working native binary, not just one architecture.

---

## 3. What happens with zero extra setup (works today)

Push this workflow file as-is and:
- **Linux build**: produces a working `.AppImage` and `.deb`. No signing
  required for Linux distribution — this just works.
- **Windows build**: produces a working `.msi`/`.exe`. Unsigned. Windows
  SmartScreen may show an "unknown publisher" warning on first run for
  users who download it — annoying but not blocking, and extremely
  common for indie/open-source Windows software.
- **macOS build**: produces a working `.dmg`, but **unsigned**. macOS
  Gatekeeper will block it harder than Windows does — by default, an
  unsigned app downloaded from the internet won't open at all without
  the user right-clicking → Open (or running a terminal command to
  remove the quarantine flag). This is a real friction point for anyone
  you share the macOS build with.

**This is a completely reasonable place to stop for now.** Shipping
unsigned and documenting the "right-click → Open" workaround in your
README is a well-worn path for solo/open-source projects that haven't
paid for developer accounts yet. Don't feel pressure to solve signing
before you've even confirmed people want to use Zeyt.

---

## 4. Signing — what it costs and what it actually buys you

If/when you decide it's worth removing that friction:

| Platform | What you need | Cost | What it fixes |
|---|---|---|---|
| macOS | Apple Developer account + signing certificate + notarization | $99/year | Removes the Gatekeeper block entirely — app opens normally on first try |
| Windows | Code signing certificate (e.g. via a CA, or Microsoft Trusted Signing) | Varies, roughly $100-400/year depending on provider, some cheaper options exist | Removes/reduces the SmartScreen warning |
| Linux | Not applicable — no equivalent gatekeeping system exists for Linux binaries | Free | N/A |

The workflow file already has the relevant secret names wired in as
environment variables (`APPLE_CERTIFICATE`, `APPLE_TEAM_ID`,
`TAURI_SIGNING_PRIVATE_KEY`, etc.) — they're simply unused/empty until
you add real values under your GitHub repo's **Settings → Secrets and
variables → Actions**. Nothing breaks by leaving them empty; the build
just produces unsigned artifacts as described in Section 3.

**Recommendation:** don't buy an Apple Developer account until Zeyt has
real outside users hitting the Gatekeeper friction in practice. $99/year
is a real cost for a side project that's still finding its audience —
treat it as a "when it's clearly worth it" upgrade, not a launch
blocker.

---

## 5. One-time repo setup checklist

Before the workflow can run at all:

1. Create the `.github/workflows/` directory in the Zeyt repo, place
   `build.yml` there.
2. Go to your GitHub repo → **Settings → Actions → General → Workflow
   permissions**, and select **"Read and write permissions."** Without
   this, the workflow will fail with a "Resource not accessible by
   integration" error when it tries to create the draft release — this
   is the single most common first-run failure with this exact setup.
3. Push to `main` once to confirm all three platform builds go green
   before relying on the tag-triggered release path.
4. When ready for a real release: tag a commit (`git tag zeyt-v0.1.0 &&
   git push origin zeyt-v0.1.0`) — this triggers the release-producing
   run and creates a **draft** GitHub Release (per `releaseDraft: true`
   in the workflow) with all platform installers attached. Review it,
   then manually publish the draft when you're ready for it to go
   public — it does not auto-publish.

---

## 6. A note on build time and cost

First builds on each platform will be slow — expect several minutes per
platform for a cold Rust compile (consistent with the ~9 minute cold
compile you already saw locally during the Phase 0 test; CI runners are
roughly comparable in raw speed to a modern laptop, sometimes slower).
The `swatinem/rust-cache` step in the workflow caches Rust build
artifacts between runs, which should make subsequent runs significantly
faster — this matters more once you're iterating on `main` pushes
regularly rather than just tagging occasional releases.

If the Zeyt repo is public, GitHub Actions minutes are free with no
practical limit for this kind of usage. If you ever make the repo
private, be aware minutes are metered and macOS runners in particular
consume minutes at a higher multiplier than Linux/Windows runners —
worth knowing, not an immediate concern at this stage.
